package com.cg.rms.service;

import com.cg.rms.bean.CandidatePersonal;

public interface IRmsService {
	
	public CandidatePersonal addCandidate(CandidatePersonal cpersonal);	
	public CandidatePersonal getCandidateInfo(int candidate_id);

}
