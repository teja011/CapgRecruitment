package com.cg.rms.repo;


import com.cg.rms.bean.CandidatePersonal;



public interface IRmsRepo {
	
	public CandidatePersonal addCandidate(CandidatePersonal cpersonal);	
	public CandidatePersonal getCandidateInfo(int candidate_id);

}
